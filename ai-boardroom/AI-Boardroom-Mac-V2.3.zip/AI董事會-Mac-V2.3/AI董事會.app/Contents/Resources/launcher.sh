#!/bin/bash
# AI 董事會啟動器。設計原則：任何一步失敗都要「講人話」，不能只留白畫面。
RES="$(cd "$(dirname "$0")" && pwd)"
cd "$RES"
LOG="$HOME/Library/Logs/AI董事會.log"
mkdir -p "$(dirname "$LOG")" 2>/dev/null

say_err(){  # 用系統對話框回報，使用者看得到
  /usr/bin/osascript -e "display dialog \"$1\" buttons {\"好\"} default button 1 with title \"AI 董事會\" with icon caution" >/dev/null 2>&1
}

# ── 找一個「真的可以跑」的 python3 ──
# ⚠️ /usr/bin/python3 在沒裝開發者工具的 Mac 上只是佔位程式，執行會跳系統安裝視窗或直接失敗
PY=""
for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3 python3; do
  P=$(command -v "$c" 2>/dev/null) || continue
  "$P" -c "import sys" >/dev/null 2>&1 && PY="$P" && break
done
if [ -z "$PY" ]; then
  say_err "這台 Mac 缺少執行本程式所需的 Python 3。\n\n請打開「App Store」搜尋並安裝 Xcode，或在「終端機」執行： xcode-select --install\n\n安裝後再打開 AI 董事會即可。"
  exit 1
fi

LOCAL_SRC=$(/sbin/md5 -q server.py | /usr/bin/cut -c1-8)
STATUS=$(/usr/bin/curl -s --max-time 1 http://localhost:6688/status 2>/dev/null)
RUN_SRC=$(printf '%s' "$STATUS" | /usr/bin/grep -o '"src": "[0-9a-f]*"' | /usr/bin/grep -o '[0-9a-f]\{8\}')

# 6688 有人在聽，但不是我們的伺服器（或是舊版）→ 只終止「我們自己的」舊版
if [ -n "$STATUS" ] && [ -z "$RUN_SRC" ]; then
  say_err "電腦上的 6688 連接埠被其他程式占用，AI 董事會無法啟動。\n\n請關閉該程式後再試一次。"
  exit 1
fi
if [ -n "$RUN_SRC" ] && [ "$RUN_SRC" != "$LOCAL_SRC" ]; then
  OLD=$(/usr/sbin/lsof -t -iTCP:6688 -sTCP:LISTEN 2>/dev/null)
  [ -n "$OLD" ] && kill $OLD 2>/dev/null && sleep 1
  RUN_SRC=""
fi

if [ -z "$RUN_SRC" ]; then
  nohup "$PY" server.py >> "$LOG" 2>&1 &
  OK=""
  for i in $(seq 1 40); do
    /usr/bin/curl -s --max-time 1 http://localhost:6688/status >/dev/null 2>&1 && OK=1 && break
    sleep 0.3
  done
  if [ -z "$OK" ]; then
    say_err "AI 董事會的背景程式沒能啟動。\n\n請把這個檔案的內容回報給我們：\n$LOG"
    exit 1
  fi
fi

if [ -d "/Applications/Google Chrome.app" ]; then
  open -na "Google Chrome" --args --app=http://localhost:6688
else
  open http://localhost:6688
fi
