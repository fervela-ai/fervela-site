#!/bin/bash
# AI 董事會 — AI 引擎一鍵安裝器（雙擊執行，或由 App 內「一鍵安裝」按鈕開啟）
# 不需要 Node.js：Claude 用官方安裝腳本、Codex 直接抓官方原生執行檔（自動判斷 CPU）。
BIN="$HOME/.local/bin"
mkdir -p "$BIN"
clear
echo "════════════════════════════════════════"
echo "  🏛  AI 董事會：AI 引擎安裝"
echo "════════════════════════════════════════"
echo ""
echo "你有哪個訂閱，就裝哪個（只要一個就能開會）："
echo ""
echo "   [1] Claude（有 Claude Pro / Max 訂閱）"
echo "   [2] GPT（有 ChatGPT Plus / Pro 訂閱）"
echo "   [3] Claude 與 GPT 都裝"
# 註：Gemini 的 CLI 訂閱模式已停用——Google 已終止免費個人帳號對此 CLI 的支援
#（IneligibleTierError／UNSUPPORTED_CLIENT，導向 Antigravity）。Gemini 請走
# 系統設定的 API Key 模式。install_gemini／ensure_node 函式保留，若 Google
# 恢復支援，把 [4] 選單行與 case 的 4 分支加回即可。
echo ""
read -p "輸入 1、2 或 3，然後按 Enter： " CH
# 只要有任何一段失敗就記下來，最後的橫幅不能謊報「完成！」（Windows 版踩過的教訓）
FAIL=0

install_claude(){
  echo ""
  if command -v claude >/dev/null 2>&1 || [ -x "$BIN/claude" ]; then
    echo "✓ Claude CLI 已經裝過了，跳過安裝。"
  else
    echo "▶ 正在安裝 Claude CLI（約一分鐘）…"
    curl -fsSL https://claude.ai/install.sh | bash || { echo "✗ 安裝失敗，請確認網路後重試。"; FAIL=1; return 1; }
  fi
  echo ""
  echo "▶ 接著登入 Claude：馬上會跳出登入畫面（瀏覽器），用你的訂閱帳號登入。"
  echo "  登入完成回到這個視窗後，輸入 /exit 再按 Enter 就會回來繼續。"
  echo ""
  read -p "　準備好就按 Enter 開始登入… " _
  if [ -x "$BIN/claude" ]; then "$BIN/claude"; else claude; fi
}

install_codex(){
  echo ""
  if command -v codex >/dev/null 2>&1 || [ -x "$BIN/codex" ]; then
    echo "✓ Codex CLI 已經裝過了，跳過安裝。"
  else
    ARCH=$(uname -m)
    if [ "$ARCH" = "arm64" ]; then A="aarch64"; else A="x86_64"; fi
    echo "▶ 正在下載 Codex CLI（$ARCH 版官方執行檔，不需要 Node.js）…"
    TMP=$(mktemp -d)
    curl -fL --progress-bar \
      "https://github.com/openai/codex/releases/latest/download/codex-${A}-apple-darwin.tar.gz" \
      -o "$TMP/codex.tar.gz" || { echo "✗ 下載失敗，請確認網路後重試。"; rm -rf "$TMP"; FAIL=1; return 1; }
    tar -xzf "$TMP/codex.tar.gz" -C "$TMP" || { echo "✗ 解壓失敗。"; rm -rf "$TMP"; FAIL=1; return 1; }
    F=$(find "$TMP" -type f -name "codex*" ! -name "*.tar.gz" | head -1)
    if [ -z "$F" ]; then echo "✗ 找不到執行檔（官方檔名可能改了，請回報）。"; rm -rf "$TMP"; FAIL=1; return 1; fi
    mv "$F" "$BIN/codex" && chmod +x "$BIN/codex" && rm -rf "$TMP"
    echo "✓ Codex CLI 安裝完成。"
  fi
  echo ""
  echo "▶ 接著登入 GPT：馬上會跳出登入畫面（瀏覽器），用你的 ChatGPT 帳號登入。"
  echo ""
  read -p "　準備好就按 Enter 開始登入… " _
  if [ -x "$BIN/codex" ]; then "$BIN/codex" login || "$BIN/codex"; else codex login || codex; fi
}

# 一鍵原則：Node.js 由安裝器自動裝，不叫使用者自己去 nodejs.org。
# 裝在 ~/.local/node（使用者層級、不需要密碼、不碰系統），移除也只要刪那個資料夾。
ensure_node(){
  command -v npm >/dev/null 2>&1 && return 0
  if [ -x "$HOME/.local/node/bin/npm" ]; then export PATH="$HOME/.local/node/bin:$PATH"; return 0; fi
  echo "▶ Gemini 需要 Node.js，正在自動安裝（免密碼，只裝進你的使用者資料夾）…"
  ARCH=$(uname -m); if [ "$ARCH" = "arm64" ]; then A="arm64"; else A="x64"; fi
  # LTS 主版號固定、小版號常變動：從官方清單解析當下的實際檔名
  NAME=$(curl -fsSL https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt | grep -o "node-v22[0-9.]*-darwin-${A}\.tar\.gz" | head -1)
  [ -z "$NAME" ] && { echo "✗ 查不到 Node.js 下載資訊，請確認網路後重試。"; FAIL=1; return 1; }
  TMP=$(mktemp -d)
  curl -fL --progress-bar "https://nodejs.org/dist/latest-v22.x/$NAME" -o "$TMP/node.tar.gz" \
    || { echo "✗ Node.js 下載失敗。"; rm -rf "$TMP"; FAIL=1; return 1; }
  tar -xzf "$TMP/node.tar.gz" -C "$TMP" || { echo "✗ 解壓失敗。"; rm -rf "$TMP"; FAIL=1; return 1; }
  rm -rf "$HOME/.local/node"
  mv "$TMP"/node-v*/ "$HOME/.local/node" && rm -rf "$TMP"
  export PATH="$HOME/.local/node/bin:$PATH"
  echo "✓ Node.js 已就緒（$("$HOME/.local/node/bin/node" -v)）"
}

install_gemini(){
  echo ""
  if command -v gemini >/dev/null 2>&1 || [ -x "$BIN/gemini" ]; then
    echo "✓ Gemini CLI 已經裝過了，跳過安裝。"
  else
    ensure_node || { read -p "按 Enter 返回… " _; return 1; }
    echo "▶ 正在安裝 Gemini CLI（約一分鐘）…"
    npm install -g @google/gemini-cli || { echo "✗ 安裝失敗，請確認網路後重試。"; FAIL=1; return 1; }
    # gemini 是 Node 腳本；App 從 Finder 啟動時 PATH 沒有 ~/.local/node/bin，
    # 直接 symlink 會因找不到 node 而失敗。放一個帶 PATH 的包裝腳本進 $BIN。
    if [ -x "$HOME/.local/node/bin/gemini" ] && ! command -v gemini >/dev/null 2>&1; then
      printf '#!/bin/bash\nexport PATH="%s:$PATH"\nexec "%s" "$@"\n' \
        "$HOME/.local/node/bin" "$HOME/.local/node/bin/gemini" > "$BIN/gemini"
      chmod +x "$BIN/gemini"
    fi
  fi
  echo ""
  echo "▶ 接著登入 Gemini，三個重點："
  echo "  1. 等一下的畫面裡，選第一項「Login with Google」按 Enter"
  echo "  2. 瀏覽器跳出登入頁：用「個人」Google 帳號登入（避開公司/學校帳號）"
  echo "  3. 瀏覽器說成功後，回到這個視窗等它顯示完成，再輸入 /quit 離開（太早關＝白登）"
  echo ""
  read -p "　準備好就按 Enter 開始登入… " _
  if [ -x "$BIN/gemini" ]; then "$BIN/gemini"; else gemini; fi
  # ⚠️ 不能只看流程有沒有跑完——瀏覽器顯示成功就關視窗的話，憑證根本沒存
  #（Windows 真機踩過：「以為成功了，結果是假的」）。驗證憑證檔才算數。
  if [ -f "$HOME/.gemini/oauth_creds.json" ]; then
    echo "✓ Gemini 已登入（憑證已確認存在）。"
  else
    FAIL=1
    echo "✗ Gemini 看起來還沒真正登入成功（找不到登入憑證）。"
    echo "  請重跑本安裝器選 4，特別注意第 3 點：瀏覽器完成後要回來等視窗顯示完成。"
  fi
}

case "$CH" in
  1) install_claude ;;
  2) install_codex ;;
  3) install_claude && install_codex ;;
  *) echo "沒有選擇，結束。" ;;
esac

echo ""
echo "════════════════════════════════════════"
if [ "$FAIL" = "1" ]; then
  echo "  尚未全部完成：上面有 ✗ 的項目請照提示補完。"
  echo "  （只要有任何一家登入成功，就能開會。）"
else
  echo "  完成！回到「AI 董事會」視窗按「🔄 重新檢查」，"
  echo "  狀態變 ✓ 就可以開會了。這個視窗可以關掉。"
fi
echo "════════════════════════════════════════"
read -p "按 Enter 結束… " _
