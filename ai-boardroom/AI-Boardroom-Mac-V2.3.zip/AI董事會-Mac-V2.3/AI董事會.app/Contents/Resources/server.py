#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI 董事會 / AI Boardroom — by Fervela.ai © 2026 Fervela. All rights reserved.

CLI 橋接伺服器（只用 Python 3 標準庫，macOS 內建 python3 即可執行）

讓網頁透過本機的 Claude Code / Codex CLI 產生回答，
用量計入兩家「訂閱額度」，不走按量計費的 API。

使用方式：
  1. 安裝並登入兩個 CLI（見 CLAUDE.md 或網頁上的指引）
  2. 終端機執行：python3 server.py（或雙擊 start.command）
  3. 瀏覽器開啟 http://localhost:6688
"""

import hashlib
import json
import os
import re
import select
import shutil
import subprocess
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# 版號唯一來源：頁首、系統設定、Info.plist、zip 檔名全部由此而來。
# 兩位數 X.Y —— X＝使用者一眼看得出「變成不同的軟體」的大改版（V1→V2＝3 家引擎變 12 家、
# 加五語與三主題）；Y＝其他所有更新（新功能、修 bug、調整）。不用第三位數：每次改完就
# 整包重發，沒有獨立的修補管道，patch 位永遠是裝飾。
APP_VERSION = "2.3"
SUPPORT_EMAIL = "lynchwu99@gmail.com"  # 問題回報信箱（介面「✉️ 回報」按鈕）

# ── 檢查更新 ──────────────────────────────────────────────
# ⚠️ 這個網址會被寫死在每一份發出去的 App 裡，**永遠不能改**——朋友手上的舊版
# 只會去問它當初被編進去的位址。所以用自有網域，背後要掛 GitHub Pages
# 或任何主機都可以，日後搬家不影響已發佈的版本。
#
# 目標檔內容（純靜態 JSON，發版時只改這三行）：
#   {"version": "2.3", "notes": "新增基礎教學", "url": "https://fervela.ai/ai-boardroom/"}
#
# 隱私：單向讀取，不送出任何資料——不帶版號、不帶識別碼、不帶使用統計。
# 唯一無法避免的是對方主機的存取紀錄會看到 IP，這是任何 HTTP 請求都一樣。
UPDATE_URL = "https://fervela.ai/ai-boardroom/version.json"
_update_cache = {"t": 0.0, "data": None}
PORT = 6688
# 自身程式的指紋：App 啟動器用它判斷「跑著的伺服器是不是舊版」，舊版就自動汰換
with open(os.path.abspath(__file__), "rb") as _f:
    SRC_HASH = hashlib.md5(_f.read()).hexdigest()[:8]
TIMEOUT_S = 180          # 單次回答上限 3 分鐘
RETRY_DELAYS_S = [5, 20, 60]  # 暫時性錯誤自動重試 3 次，間隔漸長

# ══ 引擎註冊表（12 家；V2 唯一來源，前端由 /status 取得）══
# api_style：openai＝OpenAI 相容 chat/completions；anthropic＝Messages API；gemini＝generateContent。
# cli 欄非空＝該家有官方訂閱制 CLI，可走 CLI 模式（免 API 費）。
# models 首選項空值＝CLI 預設（自動跟最新）；型號清單以各家官方現行型號維護（見懶人包）。
ENGINES = {
    "claude": {"label": "Claude", "vendor": "Anthropic", "flag": "🇺🇸", "cli": "claude",
               "api_style": "anthropic", "api_base": "https://api.anthropic.com/v1/messages",
               "key_url": "https://console.anthropic.com",
               "models": [{"v": "", "name": "CLI", "tier": "default"},
                          {"v": "claude-opus-5", "name": "Opus 5", "tier": "flagship", "in": 5, "out": 25},
                          {"v": "claude-fable-5", "name": "Fable 5", "tier": "flagship", "in": 10, "out": 50},
                          {"v": "claude-sonnet-5", "name": "Sonnet 5", "tier": "balanced", "in": 2, "out": 10},
                          {"v": "claude-haiku-4-5", "name": "Haiku 4.5", "tier": "budget", "in": 1, "out": 5}]},
    "gpt": {"label": "GPT", "vendor": "OpenAI", "flag": "🇺🇸", "cli": "codex",
            "api_style": "openai", "api_base": "https://api.openai.com/v1/chat/completions",
            "key_url": "https://platform.openai.com",
            "models": [{"v": "", "name": "CLI", "tier": "default"},
                       {"v": "gpt-5.6-sol", "name": "GPT-5.6 Sol", "tier": "flagship", "in": 5, "out": 30},
                       {"v": "gpt-5.6-terra", "name": "GPT-5.6 Terra", "tier": "balanced", "in": 2, "out": 12},
                       {"v": "gpt-5.6-luna", "name": "GPT-5.6 Luna", "tier": "budget", "in": 0.2, "out": 1.2}]},
    # ⚠️ Gemini 的 CLI 訂閱模式在 Windows 刻意停用（見 refresh_cli）：
    # 需要 Node、npm 全域安裝、互動式 TUI 登入，且真機實測出「以為登入成功
    # 其實憑證沒存」的假成功。作者決定 Windows 只主推 Claude／GPT 兩條訂閱
    # 路線，Gemini 在 Windows 走 API Key 模式。Mac 不受影響。
    "gemini": {"label": "Gemini", "vendor": "Google", "flag": "🇺🇸", "cli": "gemini",
               "api_style": "gemini",
               "api_base": "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
               "key_url": "https://aistudio.google.com",
               "models": [{"v": "", "name": "CLI", "tier": "default"},
                          {"v": "gemini-3.1-pro-preview", "name": "Gemini 3.1 Pro", "tier": "flagship", "in": 2, "out": 12},
                          {"v": "gemini-3.7-flash", "name": "Gemini 3.7 Flash", "tier": "balanced", "in": 0.75, "out": 3.75},
                          {"v": "gemini-3.5-flash-lite", "name": "Gemini 3.5 Flash-Lite", "tier": "budget", "in": 0.3, "out": 2.5}]},
    "grok": {"label": "Grok", "vendor": "xAI", "flag": "🇺🇸", "cli": "",
             "api_style": "openai", "api_base": "https://api.x.ai/v1/chat/completions",
             "key_url": "https://console.x.ai",
             "models": [{"v": "grok-4.6", "name": "Grok 4.6", "tier": "flagship", "in": 2, "out": 6},
                        {"v": "grok-4.3", "name": "Grok 4.3", "tier": "balanced", "in": 1.25, "out": 2.5},
                        {"v": "grok-code-fast-1", "name": "Grok Code Fast", "tier": "budget", "in": 1, "out": 2}]},
    "llama": {"label": "Llama", "vendor": "Meta", "flag": "🇺🇸", "cli": "",
              "api_style": "openai", "api_base": "", "base_editable": True,
              "key_url": "https://api.together.ai",
              "note": "Meta 已停止官方託管 API：請填 OpenAI 相容服務端點（Together：https://api.together.ai/v1/chat/completions；Groq；本機 Ollama：http://localhost:11434/v1/chat/completions），型號名依該服務為準",
              "models": [{"v": "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8", "name": "Llama 4 Maverick", "tier": "flagship", "in": 0.27, "out": 0.85, "approx": True},
                         {"v": "meta-llama/Llama-4-Scout-17B-16E-Instruct", "name": "Llama 4 Scout", "tier": "budget", "in": 0.18, "out": 0.59, "approx": True}]},
    "qwen": {"label": "Qwen", "vendor": "Alibaba", "flag": "🇨🇳", "cli": "",
             "api_style": "openai",
             "api_base": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions",
             "key_url": "https://bailian.console.alibabacloud.com",
             "note": "此為國際端點；中國大陸帳號請把端點改為 https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
             "base_editable": True,
             "models": [{"v": "qwen3.8-max", "name": "Qwen 3.8 Max", "tier": "flagship", "in": 2, "out": 6, "approx": True},
                        {"v": "qwen3.7-flash", "name": "Qwen 3.7 Flash", "tier": "budget", "in": 0.03, "out": 0.13, "approx": True}]},
    "deepseek": {"label": "DeepSeek", "vendor": "DeepSeek", "flag": "🇨🇳", "cli": "",
                 "api_style": "openai", "api_base": "https://api.deepseek.com/chat/completions",
                 "key_url": "https://platform.deepseek.com",
                 "models": [{"v": "deepseek-v4-pro", "name": "DeepSeek V4 Pro", "tier": "flagship", "in": 0.435, "out": 0.87},
                            {"v": "deepseek-v4-flash", "name": "DeepSeek V4 Flash", "tier": "budget", "in": 0.14, "out": 0.28}]},
    "kimi": {"label": "Kimi", "vendor": "Moonshot", "flag": "🇨🇳", "cli": "",
             "api_style": "openai", "api_base": "https://api.moonshot.ai/v1/chat/completions",
             "key_url": "https://platform.kimi.ai",
             "models": [{"v": "kimi-k3", "name": "Kimi K3", "tier": "flagship", "in": 3, "out": 15},
                        {"v": "kimi-k2.6", "name": "Kimi K2.6", "tier": "budget", "in": 0.95, "out": 4}]},
    "glm": {"label": "GLM", "vendor": "Z.ai", "flag": "🇨🇳", "cli": "",
            "api_style": "openai", "api_base": "https://api.z.ai/api/paas/v4/chat/completions",
            "key_url": "https://z.ai",
            "note": "此為國際端點；中國大陸請改 https://open.bigmodel.cn/api/paas/v4/chat/completions",
            "base_editable": True,
            "models": [{"v": "glm-5.2", "name": "GLM-5.2", "tier": "flagship", "in": 1.4, "out": 4.4},
                       {"v": "glm-4.7-flash", "name": "GLM-4.7 Flash", "tier": "budget", "in": 0, "out": 0}]},
    "minimax": {"label": "MiniMax", "vendor": "MiniMax", "flag": "🇨🇳", "cli": "",
                "api_style": "openai", "api_base": "https://api.minimax.io/v1/chat/completions",
                "key_url": "https://platform.minimax.io",
                "note": "此為國際端點；中國大陸請改 https://api.minimaxi.com/v1/chat/completions（型號名大小寫敏感）",
                "base_editable": True,
                "models": [{"v": "MiniMax-M3", "name": "MiniMax M3", "tier": "flagship", "in": 0.3, "out": 1.2},
                           {"v": "MiniMax-M2.7-highspeed", "name": "MiniMax M2.7 Highspeed", "tier": "budget", "in": 0.6, "out": 2.4}]},
    "doubao": {"label": "Doubao", "vendor": "ByteDance", "flag": "🇨🇳", "cli": "",
               "api_style": "openai", "api_base": "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
               "key_url": "https://console.volcengine.com/ark",
               "note": "中國大陸火山方舟端點（需實名）；國際用戶請改 BytePlus ModelArk：https://ark.ap-southeast.bytepluses.com/api/v3/chat/completions",
               "base_editable": True,
               "models": [{"v": "doubao-seed-2-1-pro-260628", "name": "Doubao Seed 2.1 Pro", "tier": "flagship", "in": 0.89, "out": 4.45, "approx": True},
                          {"v": "doubao-seed-2-1-turbo-260628", "name": "Doubao Seed 2.1 Turbo", "tier": "budget", "in": 0.45, "out": 2.23, "approx": True}]},
    "mistral": {"label": "Mistral", "vendor": "Mistral AI", "flag": "🇪🇺", "cli": "",
                "api_style": "openai", "api_base": "https://api.mistral.ai/v1/chat/completions",
                "key_url": "https://console.mistral.ai",
                "models": [{"v": "mistral-medium-latest", "name": "Mistral Medium", "tier": "flagship", "in": 1.5, "out": 7.5},
                           {"v": "mistral-small-latest", "name": "Mistral Small", "tier": "budget", "in": 0.15, "out": 0.6}]},
}
IS_WIN = os.name == "nt"


def _config_dir():
    """設定放在使用者資料夾，不放 App 包內——否則更新覆蓋 App 就會清空金鑰，
    分享 App 也會把金鑰一起送出去。"""
    if IS_WIN:
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "AI Boardroom")
    else:
        d = os.path.expanduser("~/Library/Application Support/AI Boardroom")
    try:
        os.makedirs(d, exist_ok=True)
        return d
    except OSError:
        pass
    # 後備位置仍須在 App 包之外，否則又會回到「更新即清空、分享夾帶金鑰」
    alt = os.path.expanduser("~/.ai-boardroom")
    try:
        os.makedirs(alt, exist_ok=True)
        return alt
    except OSError:
        return tempfile.gettempdir()


CONFIG_PATH = os.path.join(_config_dir(), "config.json")
# 舊版把設定放在 App 內——第一次啟動時搬過來，使用者不會掉設定
_legacy = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
if not os.path.exists(CONFIG_PATH) and os.path.exists(_legacy):
    try:
        shutil.copyfile(_legacy, CONFIG_PATH)
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass
    else:
        try:
            os.remove(_legacy)  # 搬完必須刪掉，否則金鑰仍留在 App 包內（分享時會夾帶）
        except OSError:
            pass
# 先前版本只複製未刪除，這些安裝的舊檔仍帶著金鑰：無條件再掃一次
if os.path.exists(_legacy) and os.path.exists(CONFIG_PATH) and \
        os.path.abspath(_legacy) != os.path.abspath(CONFIG_PATH):
    try:
        os.remove(_legacy)
    except OSError:
        pass


def load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def save_config(cfg):
    """原子寫入：先寫暫存檔再置換。
    直接 open(...,"w") 會先清空原檔，寫到一半失敗（磁碟滿等）就毀掉使用者的金鑰。"""
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(CONFIG_PATH), prefix=".cfg-")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.chmod(tmp, 0o600)  # 內含 API 金鑰，僅本人可讀
        os.replace(tmp, CONFIG_PATH)  # 同分割區的置換是原子操作
        return True
    except OSError as e:
        log(f"設定寫入失敗：{e}")
        if tmp and os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        return False


def engines_config():
    return load_config().get("engines") or {}


def engine_state(k):
    """單一引擎的即時狀態：模式（cli/api）、金鑰有無、可用性、選用模型。"""
    e = ENGINES[k]
    c = engines_config().get(k) or {}
    cli_detected = bool(e.get("cli")) and bool(CLI_CMDS.get(k))
    mode = c.get("mode") or ("cli" if cli_detected else "api")
    if mode == "cli" and not e.get("cli"):
        mode = "api"
    has_key = bool((c.get("apiKey") or "").strip())
    api_base = (c.get("apiBase") or "").strip() or e.get("api_base") or ""
    available = (mode == "cli" and cli_detected) or (mode == "api" and has_key and bool(api_base))
    model = c.get("model")
    if model is None:
        model = e["models"][0]["v"]
    # API 模式不能送空模型名：精靈只存金鑰時，自動退到第一個真實型號
    if mode == "api" and not model:
        model = next((x["v"] for x in e["models"] if x["v"]), "")
    return {"mode": mode, "cli_detected": cli_detected, "has_key": has_key,
            "api_base": api_base, "available": bool(available), "model": model}


def engines_status():
    """前端用的完整引擎表（不含 apiKey 明文）。"""
    out = {}
    for k, e in ENGINES.items():
        st = engine_state(k)
        # cli 欄位按平台過濾：Windows 的 Gemini 不給 CLI（前端會因此只顯示
        # API Key 路線，模式下拉也不出現「CLI（訂閱）」選項）
        cli_name = "" if (IS_WIN and k == "gemini") else (e.get("cli") or "")
        out[k] = {"label": e["label"], "vendor": e["vendor"], "flag": e["flag"],
                  "cli": cli_name, "api_style": e["api_style"],
                  "key_url": e.get("key_url", ""), "note": e.get("note", ""),
                  "base_editable": bool(e.get("base_editable")),
                  "api_base_default": e.get("api_base") or "",
                  "models": e["models"], **st}
    return out

# ── 各 CLI 的完整路徑（macOS 與 Windows 通用）──
# 啟動時自動偵測（which）；從捷徑啟動時 PATH 較窄，所以也掃常見安裝位置。
# 環境變數 AIB_CLAUDE_CLI / AIB_CODEX_CLI 可強制指定（測試用 mock 也走這裡）。
COMMON_BIN_DIRS = [
    os.path.expanduser("~/.local/bin"),
    os.path.expanduser("~/Library/pnpm"),
    "/opt/homebrew/bin",
    "/usr/local/bin",
    "/usr/local/opt/node@22/bin",
]
if IS_WIN:
    COMMON_BIN_DIRS = [
        os.path.expandvars(r"%USERPROFILE%\.local\bin"),
        os.path.expandvars(r"%APPDATA%\npm"),
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\claude"),
        # winget 的可攜式套件（含官方 OpenAI.Codex）把指令連結放這裡
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Links"),
    ]
EXE_EXTS = ("", ".exe", ".cmd", ".bat") if IS_WIN else ("",)


def _is_fake_codex(p):
    """V2.2 之前的 Windows 安裝器誤把沙箱輔助程式 codex-command-runner.exe
    （約 1 MB）改名成 codex.exe——那個假 codex 對任何指令都只回
    「Error: runner: no pipe-in provided」。真正的主程式超過 300 MB。
    用大小濾掉假貨，否則使用者就算用 winget 裝好真品，PATH 前面殘留的
    假檔案還是會先被抓到。（os.path.getsize 會追蹤 symlink 到本體，
    winget Links 目錄裡的連結檔不會被誤殺。）"""
    try:
        return os.path.getsize(p) < 50 * 1024 * 1024
    except OSError:
        return True  # 讀不到大小＝不可用，一樣跳過


def _find_winget_codex():
    """winget 在「沒開啟開發者模式、又非系統管理員」的電腦上建不出 Links 目錄的
    codex.exe 捷徑（symlink 權限不足，Links 是空的），只會把套件目錄塞進 PATH——
    但執行檔仍叫 codex-x86_64-pc-windows-msvc.exe，於是「codex」這個名字永遠
    解析不到（一般使用者的電腦大多是這個狀態）。這裡直接到 winget 的套件目錄
    把長檔名的主程式挖出來，App 不依賴那個時有時無的捷徑。"""
    roots = [
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Packages"),
        os.path.expandvars(r"%ProgramFiles%\WinGet\Packages"),
    ]
    for root in roots:
        try:
            subdirs = [d for d in os.listdir(root) if d.startswith("OpenAI.Codex")]
        except OSError:
            continue
        for sub in subdirs:
            d = os.path.join(root, sub)
            try:
                names = os.listdir(d)
            except OSError:
                continue
            for n in names:
                if n.startswith("codex-") and n.endswith("-pc-windows-msvc.exe"):
                    p = os.path.join(d, n)
                    if not _is_fake_codex(p):
                        return p
    return None


def find_cli(name, env_key, cfg_key):
    """優先序：config.json 手動指定 > 環境變數 > PATH > 常見安裝位置。"""
    manual = (load_config().get("cli") or {}).get(cfg_key)
    if manual:
        return manual
    forced = os.environ.get(env_key)
    if forced:
        return forced
    suspect = IS_WIN and name == "codex"
    found = shutil.which(name)
    if found and not (suspect and _is_fake_codex(found)):
        return found
    for d in COMMON_BIN_DIRS:
        for ext in EXE_EXTS:
            p = os.path.join(d, name + ext)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                if suspect and _is_fake_codex(p):
                    continue
                return p
    if suspect:
        return _find_winget_codex()
    return None


CLI_CMDS = {}


def refresh_cli():
    CLI_CMDS["claude"] = find_cli("claude", "AIB_CLAUDE_CLI", "claude")
    CLI_CMDS["gpt"] = find_cli("codex", "AIB_CODEX_CLI", "codex")
    # Windows 停用 Gemini CLI（決策見 ENGINES 註解）——回報為未偵測到，
    # 前端就會自動只給 Gemini 的 API Key 路線；Mac 照常偵測。
    CLI_CMDS["gemini"] = None if IS_WIN else find_cli("gemini", "AIB_GEMINI_CLI", "gemini")


refresh_cli()

ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def strip_ansi(s):
    return ANSI_RE.sub("", s)


def now():
    return time.strftime("%H:%M:%S")


def log(msg):
    print(f"[{now()}] {msg}", flush=True)


# 各 CLI 失敗時，真正的錯誤在 stderr 尾端；前面常是啟動橫幅與被回放的提示詞。
NOISE_RE = re.compile(
    r"^(Reading (additional input|prompt)|OpenAI Codex v|-{3,}$|workdir:|model:|provider:"
    r"|approval:|sandbox:|reasoning |session id:|user$|tokens used$|\d[\d,]*$|Loaded cached credentials)"
)
FLAG_RE = re.compile(r"^(ERROR|error)\b|錯誤|failed|Failed")


def error_tail(stderr, limit=800):
    lines = [l.strip() for l in stderr.split("\n") if l.strip()]
    flagged = list(dict.fromkeys(l for l in lines if FLAG_RE.search(l)))
    if flagged:
        msg = "\n".join(flagged)
        return msg[:limit] + "…" if len(msg) > limit else msg
    tail_lines = [l for l in lines if not NOISE_RE.search(l)] or lines
    tail = "\n".join(tail_lines[-6:])
    return "…" + tail[-limit:] if len(tail) > limit else tail


# 對方機房忙線、限流、連線中斷等「等一下就好」的錯誤，值得自動重試。
# 未登入、模型名稱錯誤、context 爆掉等屬於重試也不會好的，直接回報。
TRANSIENT_RE = re.compile(
    r"at capacity|overloaded|temporarily unavailable|rate.?limit|too many requests"
    r"|\b(429|500|502|503|504)\b|ECONNRESET|ETIMEDOUT|EPIPE|socket hang up"
    r"|connection (reset|closed|refused|error)|stream (error|disconnected)"
    r"|internal server error|try again",
    re.I,
)
FATAL_RE = re.compile(
    r"context window|ran out of room|not authenticated|not logged in|/login|unauthorized"
    r"|invalid api key|has disabled|\b(401|403|404)\b|無法執行|啟動失敗|逾時",
    re.I,
)

# 帳號層級的錯誤（未登入／組織停用／授權失效）：前端據此讓席位自動改用另一家引擎
AUTH_ERR_RE = re.compile(
    r"not authenticated|not logged in|/login|unauthorized|\b401\b"
    r"|organization has disabled|has disabled .{0,40}access"
    r"|api http 40[13]|invalid.{0,12}api.?key|incorrect api key|authentication_error"
    r"|尚未設定 api key",
    re.I,
)


def is_transient(msg):
    s = str(msg)
    if FATAL_RE.search(s):
        return False
    return bool(TRANSIENT_RE.search(s))


# 把常見錯誤翻成人話（依前端語言）
def humanize(engine, msg, lang="zh"):
    s = str(msg)
    low = s.lower()
    eng = ENGINES.get(engine, {})
    label = eng.get("label", engine)
    cli = eng.get("cli") or label
    if ("api http 401" in low or "api http 403" in low or "invalid api key" in low
            or "incorrect api key" in low or "authentication_error" in low):
        ku = eng.get("key_url", "")
        if lang == "en":
            return (f"{label}'s API key was rejected (401/403). Re-check the key in System Settings; "
                    f"get or regenerate one at {ku}.\n(Original: {s[:200]})")
        return (f"{label} 的 API Key 被拒絕（401／403）。請到系統設定重新檢查金鑰；"
                f"申請或重發金鑰：{ku}\n（原始訊息：{s[:200]}）")
    if "has disabled" in low and "access" in low:
        # 組織帳號被管理員停用 Claude Code／CLI 存取
        if lang == "en":
            return (f"Your {cli} login belongs to a company/team organization whose admin has disabled CLI access. Pick one:\n"
                    f"1. Run {cli} in Terminal and sign in with your PERSONAL subscription account instead\n"
                    f"2. Ask your org admin to enable access\n"
                    f"3. Just keep meeting — seats auto-switch to the other engine when it's available\n(Original: {s[:150]})")
        return (f"你的 {cli} 登入的是公司／團隊組織帳號，而該組織的管理員停用了 CLI 存取。三選一：\n"
                f"1. 在終端機執行 {cli}，改用你「個人」的訂閱帳號重新登入\n"
                f"2. 請組織管理員開啟存取權\n"
                f"3. 直接繼續開會——另一家引擎可用時，席位會自動改用它\n（原始訊息：{s[:150]}）")
    if ("not authenticated" in low or "not logged in" in low or "/login" in low
            or "unauthorized" in low or "401" in s):
        # ⚠️ 指引不可叫使用者開終端機（新手不會），也不可提到另一個平台的檔名
        #（Windows 資料夾裡沒有 .command，使用者會去找而找不到）。兩平台的
        # 正解都是新手引導裡的「🔧 開始安裝」——它會自動跳過已裝的部分、直接進登入。
        num = {"claude": "1", "gpt": "2", "gemini": "4"}.get(engine, "")
        if lang == "en":
            return (f"{cli} is installed but not signed in (one-time setup, ~30s):\n"
                    f"Click 「❓ Setup Wizard」 (top right) → pick this AI → 「🔧 Install」 → "
                    f"enter {num} → finish the browser sign-in as prompted.\n(Original: {s[:150]})")
        return (f"{cli} 已安裝但尚未登入（一次性設定，約 30 秒）：\n"
                f"按右上角「❓ 新手引導」→ 選這家 AI →「🔧 開始安裝」→ 輸入 {num} → "
                f"照畫面在瀏覽器完成登入，回來按「重新檢查」。\n（原始訊息：{s[:150]}）")
    if "rate" in low and "limit" in low or "429" in s:
        if lang == "en":
            return f"{cli}'s subscription quota is being rate-limited; automatic retries failed. Try again in a few minutes.\n(Original: {s[:200]})"
        return f"{cli} 的訂閱額度暫時被限流，已自動重試仍失敗。休息幾分鐘再試。\n（原始訊息：{s[:200]}）"
    if "model" in low and ("not found" in low or "unknown" in low or "invalid" in low):
        if lang == "en":
            return f"{cli} doesn't recognize the selected model. Pick another model in System Settings.\n(Original: {s[:200]})"
        return f"{cli} 不認得目前選的模型名稱。請在設定裡換一個模型。\n（原始訊息：{s[:200]}）"
    return s


def build_command(engine, prompt, model, img_paths):
    """組出對應 CLI 的指令。提示詞一律走 stdin（命令列參數有長度上限，長會議記錄會爆掉）。"""
    cmd = CLI_CMDS.get(engine)
    if not cmd:
        return None
    if engine == "claude":
        p = prompt
        if img_paths:
            p = ("請先用 Read 工具開啟並仔細查看以下圖片檔案，再回答：\n"
                 + "\n".join(img_paths) + "\n\n" + prompt)
        # --allowedTools：-p 非互動模式下無法跳出權限詢問，未預先授權的工具會被直接拒絕
        args = [cmd, "-p"]
        if model:
            args += ["--model", model]
        # 只授權 Read：-p 模式無法跳權限確認，若連 WebFetch/WebSearch 都預先授權，
        # 附件或貼上的網路文字可能誘導模型把會議內容送出去
        args += ["--allowedTools", "Read", "--add-dir", tempfile.gettempdir()]
        return {"args": args, "stdin": p}
    if engine == "gpt":
        # --skip-git-repo-check：codex 預設拒絕在非 git 目錄執行
        args = [cmd, "exec", "--skip-git-repo-check"]
        # Windows 預防措施：本 App 被 Smart App Control 逼著「以系統管理員身分執行」，
        # 提權狀態下 codex 會偏好「elevated」原生沙箱——那需要管理員先跑過一次性
        # 設定（建沙箱帳號＋防火牆規則），一般使用者沒做過。指定 unelevated（用目前
        # 使用者的受限權杖）避開這個相依。註：曾誤判這是「no pipe-in provided」的
        # 解法——那個錯誤真正的原因是舊安裝器把 codex-command-runner.exe 誤改名成
        # codex.exe（見 _is_fake_codex），與沙箱模式無關。
        if IS_WIN:
            args += ["-c", 'windows.sandbox="unelevated"']
        for ip in img_paths:
            args += ["-i", ip]
        if model:
            args += ["-m", model]
        args += ["-"]
        return {"args": args, "stdin": prompt}
    if engine == "gemini":
        # gemini CLI：提示詞走 -p；圖片以 @路徑 引用
        p = ("".join("@" + ip + "\n" for ip in img_paths)) + prompt
        args = [cmd]
        if model:
            args += ["-m", model]
        args += ["-p", p]
        return {"args": args, "stdin": None}
    return None


def run_once(engine, system, prompt, model, img_paths, child_holder):
    full = (system + "\n\n" + prompt) if system else prompt
    c = build_command(engine, full, model, img_paths)
    if c is None:
        cli = "claude" if engine == "claude" else "codex"
        num = {"claude": "1", "gpt": "2", "gemini": "4"}.get(engine, "")
        return {"error": (f"找不到 {cli}。請按右上角「❓ 新手引導」→ 選這家 AI →"
                          f"「🔧 開始安裝」→ 輸入 {num}，照畫面完成安裝與登入。")}
    try:
        # cwd 固定用系統暫存目錄：App 重建時本目錄可能被刪除，
        # 若讓子程序繼承已消失的工作目錄，CLI 會以 ENOENT／os error 2 全數失敗
        argv = list(c["args"])
        # ⚠️ Windows：CreateProcess 不能直接執行 .cmd／.bat（find_cli 的 EXE_EXTS
        # 允許回傳這兩種），必須交給 cmd.exe 代跑，否則會以 OSError 全數失敗。
        if IS_WIN and argv and str(argv[0]).lower().endswith((".cmd", ".bat")):
            argv = ["cmd", "/c"] + argv
        # ⚠️ Windows：主控台程式預設會彈出一個黑色視窗，每次董事發言都閃一個出來。
        # CREATE_NO_WINDOW 讓它在背景安靜執行（macOS／Linux 沒有這個問題）。
        extra = {"creationflags": 0x08000000} if IS_WIN else {}
        child = subprocess.Popen(
            argv, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            cwd=tempfile.gettempdir(), **extra
        )
    except OSError as e:
        return {"error": f"{c['args'][0]} 無法執行（是否已安裝並登入？）：{e}"}
    child_holder["child"] = child
    try:
        stdin_data = c["stdin"].encode("utf-8") if c["stdin"] is not None else None
        out, err = child.communicate(input=stdin_data, timeout=TIMEOUT_S)
    except subprocess.TimeoutExpired:
        child.kill()
        child.communicate()
        return {"error": f"CLI 執行逾時（{TIMEOUT_S} 秒）"}
    finally:
        child_holder["child"] = None
    stdout = strip_ansi(out.decode("utf-8", "replace")).strip()
    stderr = strip_ansi(err.decode("utf-8", "replace")).strip()
    # CLI 裝了但沒登入時，訊息會走 stdout 且結束碼可能是 0——轉成明確指引
    if stdout and len(stdout) < 200 and re.search(r"not logged in|please run /login", stdout, re.I):
        return {"error": stdout}
    if child.returncode != 0:
        # ⚠️ 鐵律：結束碼非 0 就是失敗，不管 stdout 有沒有內容。
        # 實測 Claude CLI 型號不被支援時，會把「There's an issue with the selected
        # model…」印到 stdout 並以 1 結束；只看 stdout 是否為空會把它當成成功發言。
        log(f"--- {c['args'][0]} 失敗，完整 stderr ---\n{stderr}\n--- stderr 結束 ---")
        # ⚠️ 兩個串流都要留：claude 把「型號不被支援」寫在 stdout，卻同時往 stderr 印
        # 無關的 auto-compact 警告。用 `stderr or stdout` 會把真正的原因丟掉，
        # 導致自動退回預設模型的判斷永遠比對不到。
        parts = [x for x in (error_tail(stderr), stdout) if x]
        return {"error": f"結束碼 {child.returncode}：" + ("\n".join(parts) or "無輸出")}
    return {"text": stdout or stderr}


IS_EN_HINT = [False]  # 由 /cli 依請求語言設定，供 API 模式的提示文字用
# 需涵蓋各 CLI 實際印出的說法（實測 Claude Code：
# "There's an issue with the selected model (xxx). It may not exist or you may not have access to it."）
MODEL_UNKNOWN_RE = re.compile(
    # 各 CLI 的實際說法差很多，實測：
    #   claude → "There's an issue with the selected model (X). It may not exist or you may not have access to it."
    #   codex  → {"type":"invalid_request_error","message":"The 'X' model is not supported when using Codex with a ChatGPT account."}
    # 視窗放寬到 60 字，因為型號名稱會被引號包起來、把關鍵字往後推。
    r"model.{0,60}(not found|unknown|invalid|unsupported|not supported"
    r"|does not exist|not available|no access|not recognize)"
    r"|issue with the selected model"
    r"|may not exist or you may not have access"
    r"|not supported when using codex"
    r"|is not a model this version"          # claude CLI 對未知型號的 stderr 說法
    r"|not a model this version of"
    r"|unknown model|unrecognized model|invalid model|no such model",
    re.I | re.S)


def api_call(engine, system, prompt, model):
    """API 模式：以標準庫 urllib 直呼各家 REST 端點。三種轉接器：openai 相容／anthropic／gemini。"""
    e = ENGINES[engine]
    st = engine_state(engine)
    key = ((engines_config().get(engine) or {}).get("apiKey") or "").strip()
    base = st["api_base"]
    style = e["api_style"]
    if not key:
        return {"error": f"{e['label']} 尚未設定 API Key"}
    if not base:
        return {"error": f"{e['label']} 尚未設定 API 端點（Base URL）"}
    if style == "anthropic":
        url = base
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01",
                   "content-type": "application/json"}
        body = {"model": model or "claude-sonnet-5", "max_tokens": 16384,
                "messages": [{"role": "user", "content": prompt}]}
        if system:
            body["system"] = system
        def parse(d):
            txt = "".join(b.get("text", "") for b in d.get("content", []))
            if d.get("stop_reason") == "max_tokens":
                txt += "\n\n（⚠️ 回覆長度達上限被截斷，可請該席再補充後半段）"
            return txt
    elif style == "gemini":
        m = model or "gemini-3.6-flash"
        url = base.replace("{model}", m)
        headers = {"x-goog-api-key": key, "content-type": "application/json"}
        body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}]}
        if system:
            body["system_instruction"] = {"parts": [{"text": system}]}
        def parse(d):
            cand = (d.get("candidates") or [{}])[0]
            return "".join(p.get("text", "") for p in (cand.get("content") or {}).get("parts", []))
    else:  # openai 相容
        url = base
        headers = {"Authorization": f"Bearer {key}", "content-type": "application/json"}
        msgs = ([{"role": "system", "content": system}] if system else []) + \
               [{"role": "user", "content": prompt}]
        body = {"model": model, "messages": msgs, "stream": False}
        def parse(d):
            return ((d.get("choices") or [{}])[0].get("message") or {}).get("content", "")
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                 headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as ex:
        detail = ""
        try:
            detail = ex.read().decode("utf-8", "replace")[:300]
        except OSError:
            pass
        return {"error": f"API HTTP {ex.code}：{detail or ex.reason}"}
    except Exception as ex:
        return {"error": f"API 連線失敗：{ex}"}
    text = (parse(data) or "").strip()
    if not text:
        return {"error": f"API 回應解析不到內容：{json.dumps(data, ensure_ascii=False)[:300]}"}
    return {"text": text}


def run_cli(engine, system, prompt, model, img_paths, child_holder, is_aborted):
    """統一執行入口（CLI 或 API 模式）＋自動重試：暫時性故障隔一段時間重來，主席中斷立刻停止。
    CLI 模式下不認得指定型號時，自動改用該 CLI 預設模型重跑一次並註記。"""
    api_mode = engine_state(engine)["mode"] == "api"
    attempt = 0
    while True:
        if api_mode:
            r = api_call(engine, system, prompt, model)
            if img_paths and "text" in r:
                note = ("\n\n（註：本席為 API 模式，暫不支援圖片，本次僅讀取文字內容）" if not IS_EN_HINT[0]
                        else "\n\n(Note: this seat runs in API mode and cannot read images yet — text only.)")
                r["text"] = r["text"] + note
        else:
            r = run_once(engine, system, prompt, model, img_paths, child_holder)
            if "error" in r and model and MODEL_UNKNOWN_RE.search(str(r["error"])) and not is_aborted():
                log(f"{engine} 不認得型號 {model}，改用 CLI 預設模型重跑")
                r = run_once(engine, system, prompt, None, img_paths, child_holder)
                if "text" in r:
                    r["text"] = f"（註：指定的模型 {model} 不被支援，本則改用 CLI 預設模型）\n\n" + r["text"]
        if "error" not in r or attempt >= len(RETRY_DELAYS_S):
            return r
        if is_aborted() or not is_transient(r["error"]):
            return r
        wait = RETRY_DELAYS_S[attempt]
        log(f"{engine} 遇到暫時性錯誤，{wait} 秒後重試（第 {attempt + 1}/{len(RETRY_DELAYS_S)} 次）："
            f"{str(r['error'])[:120]}")
        deadline = time.time() + wait
        while time.time() < deadline:
            if is_aborted():
                return r
            time.sleep(0.5)
        attempt += 1


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):  # 改用自己的 log 格式
        pass

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    # 不再對外開放 CORS：前端與伺服器同源，開放等於讓任何網頁都能存取本機 API
    def _cors(self):
        pass

    LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1")

    def _same_origin(self):
        """擋跨站請求：瀏覽器一定會帶 Origin；同時擋 DNS rebinding（Host 必須是 localhost）。
        注意：ParseResult.port 是延遲解析，畸形埠號會在「取用時」才丟 ValueError，
        因此所有屬性存取都要包在 try 內，否則例外會從安全檢查裡逃出去。"""
        # 用 urlsplit 解析 Host，才能正確處理 IPv6 字面值 [::1]:6688
        try:
            host = urllib.parse.urlsplit("//" + (self.headers.get("Host") or "")).hostname or ""
        except ValueError:
            return False
        if host not in self.LOCAL_HOSTS:
            return False
        origin = self.headers.get("Origin")
        if origin:
            try:
                o = urllib.parse.urlparse(origin)
                # 埠號必須完全相符：允許 None 等於放行 localhost:80／443 上的任何網頁
                ok = (o.hostname in self.LOCAL_HOSTS) and (o.port == PORT)
            except ValueError:
                return False
            if not ok:
                return False
        ref = self.headers.get("Referer")
        if not origin and ref:
            try:
                ok = urllib.parse.urlparse(ref).hostname in self.LOCAL_HOSTS
            except ValueError:
                return False
            if not ok:
                return False
        return True

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except OSError:
            pass  # 客戶端已離線

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai-boardroom.html")
            if not os.path.isfile(fp):
                return self._json(404, {"error": "找不到 ai-boardroom.html，請把本檔和網頁放在同一個資料夾。"})
            with open(fp, "rb") as f:
                buf = f.read()
            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", "text/html; charset=utf-8")
            # 禁止快取：App 更新後若瀏覽器沿用舊 HTML，會出現「改了設定卻沒反應」的假故障
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.send_header("Content-Length", str(len(buf)))
            self.end_headers()
            self.wfile.write(buf)
            return
        if self.path == "/status":
            refresh_cli()  # 每次都重新偵測：使用者裝好 CLI 後按「重新檢查」即可生效，不用重啟
            self._json(200, {"engines": engines_status(), "support_email": SUPPORT_EMAIL,
                             "src": SRC_HASH, "version": APP_VERSION})
            return
        if self.path == "/update":
            # 由伺服器代抓：網頁在 localhost，直接抓外部網域會被 CORS 擋住。
            # 任何失敗都安靜回空物件——沒網路、網址還沒架好、主機掛了，
            # 都不可以影響使用者開會。
            now = time.time()
            if _update_cache["data"] is not None and now - _update_cache["t"] < 21600:
                return self._json(200, _update_cache["data"])
            data = {}
            try:
                req = urllib.request.Request(UPDATE_URL, headers={"User-Agent": "AI-Boardroom"})
                with urllib.request.urlopen(req, timeout=4) as r:
                    raw = json.loads(r.read(8192).decode("utf-8", "replace"))
                if isinstance(raw, dict) and isinstance(raw.get("version"), str):
                    data = {"version": raw["version"][:20],
                            "notes": str(raw.get("notes", ""))[:200],
                            "url": raw.get("url") if isinstance(raw.get("url"), str)
                                   and raw.get("url", "").startswith("https://") else ""}
            except Exception:
                data = {}
            _update_cache["t"] = now
            _update_cache["data"] = data
            return self._json(200, data)
        if self.path == "/license":
            # App 包內在 Resources/ 根層；直接跑原始碼時在 src/guide/
            here = os.path.dirname(os.path.abspath(__file__))
            for fp in (os.path.join(here, "LICENSE.txt"),
                       os.path.join(here, "guide", "LICENSE.txt")):
                try:
                    with open(fp, encoding="utf-8") as f:
                        return self._json(200, {"text": f.read()})
                except OSError:
                    continue
            return self._json(404, {"error": "LICENSE.txt not found"})
        if self.path == "/config":
            if not self._same_origin():
                return self._json(403, {"error": "cross-site request blocked"})
            cfg = load_config()
            self._json(200, {
                "detected": {k: (os.path.basename(v) if v else None) for k, v in CLI_CMDS.items()},
                "cli": cfg.get("cli") or {},
                "engines": engines_status(),
            })
            return
        self._json(404, {"error": "not found"})

    def _drain(self):
        """提前回應時要把請求主體讀掉，否則 HTTP/1.1 keep-alive 下
        殘留的位元組會被當成下一個請求的開頭。"""
        try:
            n = int(self.headers.get("Content-Length", 0))
        except ValueError:
            n = 0
        if n > 0:
            try:
                self.rfile.read(n)
            except OSError:
                pass

    def do_POST(self):
        if not self._same_origin():
            self._drain()
            log(f"已擋下跨站請求：{self.path}（Origin={self.headers.get('Origin')}）")
            return self._json(403, {"error": "cross-site request blocked"})
        if self.path == "/install":
            # 由網頁「一鍵安裝」按鈕觸發：開一個終端機／PowerShell 視窗跑互動式安裝器
            here = os.path.dirname(os.path.abspath(__file__))
            inst_name = "install-ai-engine.ps1" if IS_WIN else "安裝AI引擎.command"
            inst = os.path.join(here, inst_name)
            if not os.path.isfile(inst):
                self._drain()
                return self._json(404, {"error": f"找不到安裝器（{inst_name}）"})
            try:
                if IS_WIN:
                    subprocess.Popen(["cmd", "/c", "start", "", "powershell",
                                      "-NoExit", "-ExecutionPolicy", "Bypass", "-File", inst])
                else:
                    subprocess.Popen(["open", "-a", "Terminal", inst])
            except OSError as e:
                return self._json(500, {"error": f"無法開啟安裝視窗：{e}"})
            log("已開啟 AI 引擎安裝器視窗")
            return self._json(200, {"ok": True})
        if self.path == "/config":
            try:
                length = int(self.headers.get("Content-Length", 0))
                data = json.loads(self.rfile.read(length) or b"{}")
            except (ValueError, json.JSONDecodeError):
                return self._json(400, {"error": "無法解析請求"})
            cfg = load_config()
            if isinstance(data.get("cli"), dict):
                cfg["cli"] = {k: v.strip() for k, v in data["cli"].items()
                              if k in ("claude", "codex", "gemini") and isinstance(v, str) and v.strip()}
            if isinstance(data.get("engines"), dict):
                store = cfg.get("engines") or {}
                for k, v in data["engines"].items():
                    if k not in ENGINES or not isinstance(v, dict):
                        continue
                    cur = store.get(k) or {}
                    if v.get("mode") in ("cli", "api"):
                        cur["mode"] = v["mode"]
                    if "model" in v:
                        cur["model"] = str(v["model"]).strip()
                    if "apiBase" in v:
                        cur["apiBase"] = str(v["apiBase"]).strip()
                    # apiKey：空字串＝不變；"CLEAR"＝清除；其他＝更新
                    ak = v.get("apiKey")
                    if isinstance(ak, str) and ak.strip():
                        if ak.strip() == "CLEAR":
                            cur["apiKey"] = ""
                        else:
                            cur["apiKey"] = ak.strip()
                    store[k] = cur
                cfg["engines"] = store
            if not save_config(cfg):
                return self._json(500, {"error": "設定寫入失敗（磁碟空間或權限問題），請稍後再試"})
            refresh_cli()
            log("設定已更新（config.json），CLI 路徑已重新偵測")
            return self._json(200, {"ok": True, "engines": engines_status(),
                                    "detected": dict(CLI_CMDS)})
        if self.path != "/cli":
            self._drain()
            return self._json(404, {"error": "not found"})
        try:
            length = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self._json(400, {"error": "無法解析請求"})
        engine = data.get("engine")
        prompt = data.get("prompt")
        system = data.get("system") or ""
        images = data.get("images") or []
        lang = "zh" if data.get("lang") == "zh" else "en"  # 非中文一律英文，與前端語言鏈一致
        if not engine or not prompt or engine not in ENGINES:
            return self._json(400, {"error": "缺少參數或未知引擎"})
        st = engine_state(engine)
        IS_EN_HINT[0] = (lang != "zh")
        model = data.get("model") if "model" in data else st["model"]
        label = ENGINES[engine]["label"]
        if not st["available"]:
            if st["mode"] == "cli":
                msg = (f"{label} CLI not found. Open “❓ Guide” to install, or switch this engine to API mode in System Settings."
                       if lang == "en" else
                       f"找不到 {label} 的 CLI。請按「❓ 新手引導」安裝，或到系統設定把 {label} 切成 API 模式。")
            else:
                ku = ENGINES[engine].get("key_url", "")
                msg = (f"{label} has no API key yet. Paste one in System Settings (get a key at {ku})."
                       if lang == "en" else
                       f"{label} 還沒設定 API Key。請到系統設定貼上金鑰（申請網址：{ku}）。")
            return self._json(200, {"error": msg, "authError": True})

        # 圖片 dataURL 落地成暫存檔給 CLI 讀
        img_paths = []
        for im in images[:10]:
            m = re.match(r"^data:(image/[\w+]+);base64,(.+)$", im.get("dataUrl", ""), re.S)
            if not m:
                continue
            ext = m.group(1).split("/")[1].replace("jpeg", "jpg").replace("+xml", "")
            fp = tempfile.NamedTemporaryFile(prefix="aib-img-", suffix="." + ext, delete=False)
            import base64
            fp.write(base64.b64decode(m.group(2)))
            fp.close()
            img_paths.append(fp.name)

        log(f"{engine} 開始（{model or '預設模型'}"
            f"{'，含 ' + str(len(img_paths)) + ' 張圖' if img_paths else ''}）…")

        # 網頁按「中斷」會中止連線；偵測到連線提前關閉就終止還在跑的 CLI，避免白燒額度
        aborted = {"v": False}
        child_holder = {"child": None}

        def watch_abort():
            conn = self.connection
            while not aborted["v"]:
                try:
                    r, _, _ = select.select([conn], [], [], 0.5)
                    if r:
                        # 客戶端不會再送資料；能讀到 b"" 表示對方關了連線
                        try:
                            chunk = conn.recv(1, 0x2)  # MSG_PEEK
                        except OSError:
                            chunk = b""
                        if chunk == b"":
                            aborted["v"] = True
                            ch = child_holder.get("child")
                            if ch:
                                log(f"{engine} 已被主席中斷，終止 CLI 程序")
                                try:
                                    ch.kill()
                                except OSError:
                                    pass
                            return
                except (OSError, ValueError):
                    return
                if getattr(self, "_done", False):
                    return

        watcher = threading.Thread(target=watch_abort, daemon=True)
        watcher.start()
        try:
            r = run_cli(engine, system, prompt, model, img_paths,
                        child_holder, lambda: aborted["v"])
        finally:
            self._done = True
        for p in img_paths:
            try:
                os.unlink(p)
            except OSError:
                pass
        if "error" in r:
            if AUTH_ERR_RE.search(str(r["error"])):
                r["authError"] = True
            r["error"] = humanize(engine, r["error"], lang)
        log(f"{engine} {'失敗：' + str(r.get('error'))[:200] if 'error' in r else '完成'}")
        if aborted["v"]:
            return  # 對方已離線，不用回了
        self._json(200, r)


def main():
    for name, key in (("claude", "claude"), ("codex", "gpt")):
        p = CLI_CMDS[key]
        log(f"{name} CLI：{p or '⚠️ 未找到（該席發言時會提示安裝方式）'}")
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print("✅ AI 董事會伺服器已啟動 — by Fervela.ai")
    print(f"   請用瀏覽器開啟 → http://localhost:{PORT}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已關閉，散會。")


if __name__ == "__main__":
    main()
