#!/bin/bash
# AI 董事會 by Fervela.ai — 一鍵解鎖（首次開啟用）
# 用途：解除 macOS 對下載檔案的隔離標記，讓 App 可以正常打開。
# 用法：對本檔按「右鍵 → 打開」（第一次要用右鍵，直接雙擊會被系統擋下）。
cd "$(dirname "$0")"
clear
echo "════════════════════════════════════════"
echo "  🏛  AI 董事會 — 一鍵解鎖"
echo "     by Fervela.ai"
echo "════════════════════════════════════════"
echo ""

APP=""
for cand in "./AI董事會.app" "/Applications/AI董事會.app" "$HOME/Downloads/AI董事會.app" "$HOME/Desktop/AI董事會.app"; do
  [ -d "$cand" ] && APP="$cand" && break
done

if [ -z "$APP" ]; then
  echo "✗ 找不到 AI董事會.app"
  echo ""
  echo "  請先把 AI董事會.app 拖進「應用程式」資料夾，"
  echo "  或把本檔案和 AI董事會.app 放在同一個資料夾，再執行一次。"
  echo ""
  read -p "按 Enter 結束… " _
  exit 1
fi

echo "▶ 找到：$APP"
echo "▶ 正在解除封鎖…"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null
if command -v codesign >/dev/null 2>&1; then
  codesign --force --deep -s - "$APP" >/dev/null 2>&1
fi

echo "✓ 完成！正在幫你打開 App…"
open "$APP"
echo ""
echo "════════════════════════════════════════"
echo "  以後直接雙擊 AI董事會 就能使用。"
echo "  這個視窗可以關掉了。"
echo "════════════════════════════════════════"
read -p "按 Enter 結束… " _
