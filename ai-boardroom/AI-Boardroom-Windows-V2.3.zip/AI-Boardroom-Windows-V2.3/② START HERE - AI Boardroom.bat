@echo off
rem AI Boardroom by Fervela.ai - Windows launcher (Beta)
rem Keep this file ASCII-only: Chinese text in .bat breaks on many codepages.
rem
rem IMPORTANT: never call powershell from this file. A .bat that spawns
rem PowerShell to make network requests is a classic malware pattern and gets
rem blocked by Smart App Control / Defender even after the file is unblocked.
rem Python is code-signed and trusted, so wait_server.py does the probing.
cd /d "%~dp0program"

rem Find a REAL python. `where python` also matches the Microsoft Store alias
rem stub, which exits without running anything - so verify by executing it.
set "PYEXE="
for %%c in (py python3 python) do (
  if not defined PYEXE (
    %%c -c "import sys" >nul 2>nul && set "PYEXE=%%c"
  )
)
if not defined PYEXE (
  echo Python 3 is required. Opening Microsoft Store...
  echo If the Store does not open, install "Python 3.12" from apps.microsoft.com
  start "" "ms-windows-store://pdp/?ProductId=9NCVDN91XZQP"
  echo After installing Python, double-click this file again.
  pause
  exit /b 1
)

rem Already running?
%PYEXE% wait_server.py once >nul 2>nul
if not errorlevel 1 goto open

start "" pythonw server.py 2>nul || start "" /min %PYEXE% server.py

%PYEXE% wait_server.py wait >nul 2>nul
if errorlevel 1 (
  echo Server failed to start. Run this in a terminal to see the error:
  echo    %PYEXE% server.py
  pause
  exit /b 1
)

:open
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app=http://localhost:6688
) else (
  start "" msedge --app=http://localhost:6688
)
exit /b 0
