"""啟動器輔助：探測伺服器是否就緒。

存在的理由：Windows 啟動器原本用 PowerShell 的 Invoke-RestMethod 做這件事，
但「.bat 啟動 PowerShell 連網」是惡意程式的典型特徵，會被 Smart App Control
與 Defender 攔下（即使檔案已解除封鎖）。Python 有微軟簽章、屬可信程式，
改由它探測就不會觸發攔截。

用法：
    python wait_server.py once    → 探測一次，通了回傳 0
    python wait_server.py wait    → 最多等約 12 秒，通了回傳 0，逾時回傳 1
"""
import sys
import time
import urllib.request

URL = "http://localhost:6688/status"


def probe(timeout=1.0):
    try:
        with urllib.request.urlopen(URL, timeout=timeout):
            return True
    except Exception:
        return False


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "once"
    if mode == "once":
        return 0 if probe() else 1
    for _ in range(40):            # 40 × 0.3 秒 ≈ 12 秒
        if probe():
            return 0
        time.sleep(0.3)
    return 1


if __name__ == "__main__":
    sys.exit(main())
