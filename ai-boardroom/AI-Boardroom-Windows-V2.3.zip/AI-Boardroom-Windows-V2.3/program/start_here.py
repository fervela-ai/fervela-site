"""AI 董事會 — 備用啟動器（Windows）

存在的理由：Windows 11 的「智慧型應用程式控制」(Smart App Control) 會封鎖
未簽章的 .bat 啟動器，而且那個對話框**沒有「仍要執行」可按**，等於死路。
Python 直譯器本身有微軟簽章、屬於可信程式，因此改由 Python 完成同樣的工作。

用法：雙擊本檔（需先安裝 Python 3）。
"""
import os
import subprocess
import sys
import time
import urllib.request
import webbrowser

PORT = 6688
URL = "http://localhost:%d" % PORT
HERE = os.path.dirname(os.path.abspath(__file__))
# 本檔放在分享包最外層，server.py 在 program/ 底下；
# 但若有人把本檔搬進 program/ 也要能運作，所以兩個位置都找。
for _cand in (os.path.join(HERE, "program"), HERE):
    if os.path.exists(os.path.join(_cand, "server.py")):
        PROGRAM = _cand
        break
else:
    PROGRAM = os.path.join(HERE, "program")
SERVER = os.path.join(PROGRAM, "server.py")


def alive(timeout=1.0):
    try:
        with urllib.request.urlopen(URL + "/status", timeout=timeout):
            return True
    except Exception:
        return False


def open_browser():
    """優先用 Chrome 的 --app 模式開出無網址列視窗，沒有就退回預設瀏覽器。"""
    for base in (os.environ.get("ProgramFiles", ""),
                 os.environ.get("ProgramFiles(x86)", ""),
                 os.environ.get("LOCALAPPDATA", "")):
        if not base:
            continue
        chrome = os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")
        if os.path.exists(chrome):
            subprocess.Popen([chrome, "--app=" + URL])
            return
    webbrowser.open(URL)


def main():
    if not os.path.exists(SERVER):
        print("找不到 server.py。請確認本檔與 program 資料夾放在一起，沒有被搬走。")
        input("按 Enter 關閉…")
        return 1

    if not alive():
        # pythonw 沒有主控台視窗；沒有的話退回目前這個直譯器
        pythonw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        exe = pythonw if os.path.exists(pythonw) else sys.executable
        flags = 0x08000000 if os.name == "nt" else 0    # CREATE_NO_WINDOW
        subprocess.Popen([exe, SERVER], cwd=PROGRAM, creationflags=flags)

        for _ in range(40):                              # 最多等約 12 秒
            if alive():
                break
            time.sleep(0.3)
        else:
            print("伺服器沒有在預期時間內啟動。")
            print("請在這個資料夾開啟終端機並執行下列指令，就能看到完整錯誤訊息：")
            print("    python server.py")
            input("按 Enter 關閉…")
            return 1

    open_browser()
    return 0


if __name__ == "__main__":
    sys.exit(main())
