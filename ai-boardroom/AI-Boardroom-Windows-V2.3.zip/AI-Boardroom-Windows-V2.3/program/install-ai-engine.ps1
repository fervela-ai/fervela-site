﻿# AI 董事會 by Fervela.ai — AI 引擎一鍵安裝器（Windows Beta）
# 由 AI-Boardroom.bat 開啟的網頁按「一鍵安裝」觸發，或在本檔按右鍵→以 PowerShell 執行
$ErrorActionPreference = "Stop"
$bin = Join-Path $env:USERPROFILE ".local\bin"
New-Item -ItemType Directory -Force -Path $bin | Out-Null

Write-Host "=========================================="
Write-Host "  AI 董事會：AI 引擎安裝（Windows Beta）"
Write-Host "=========================================="
Write-Host ""
Write-Host "你有哪個訂閱，就裝哪個（只要一個就能開會）："
Write-Host ""
Write-Host "   [1] Claude（Claude Pro / Max 訂閱）"
Write-Host "   [2] GPT（ChatGPT Plus / Pro 訂閱）"
Write-Host "   [3] Claude 與 GPT 都裝"
# 註：Gemini 的 CLI 訂閱模式在 Windows 刻意不提供（假登入、Node 相依等問題，
# 見 CHANGELOG）。Windows 上 Gemini 請走系統設定的 API Key 模式。
# Install-Gemini 函式保留，要恢復時把 [4] 選單行與 switch 的 "4" 分支加回即可。
Write-Host ""
$ch = Read-Host "輸入 1、2 或 3 後按 Enter"
# 只要有任何一段登入失敗就記下來，最後的橫幅不能謊報「完成！」
$script:LoginFailed = @()

function Install-Claude {
  if (Get-Command claude -ErrorAction SilentlyContinue) {
    Write-Host "OK Claude CLI 已經裝過了，跳過安裝。"
  } else {
    Write-Host ">> 正在安裝 Claude CLI（約一分鐘）..."
    irm https://claude.ai/install.ps1 | iex
    $env:Path = "$env:Path;$bin"
  }
  Write-Host ""
  Write-Host ">> 接著登入 Claude：輸入 /login 依瀏覽器指示用你的訂閱帳號登入；"
  Write-Host "   若跳出帳號/工作區選擇，請選「個人」而不是公司組織。"
  Write-Host "   登入完成後輸入 /exit 返回這裡。"
  Read-Host "  準備好就按 Enter 開始登入" | Out-Null
  $claudeCmd = Get-Command claude -ErrorAction SilentlyContinue
  if ($claudeCmd) { & $claudeCmd.Source } else { & (Join-Path $bin "claude.exe") }
}

# 判斷某個路徑是不是「真的」codex 主程式。
# ⚠️ 背景：官方 zip 裡有「三個」exe——
#     codex-command-runner.exe         （沙箱輔助程式，約 1 MB）
#     codex-windows-sandbox-setup.exe  （沙箱安裝程式，約 9 MB）
#     codex-<arch>-pc-windows-msvc.exe （主程式，350 MB 以上）
# 本安裝器的舊版（V2.2 之前）解壓後「取字母排序第一個 codex*.exe 改名」——
# 第一名正是 command-runner，於是把輔助程式當成 codex 裝進系統；那個假 codex
# 不管下什麼指令一律回「Error: runner: no pipe-in provided」。
# 用「實際執行 --version」判斷最可靠：真品回 codex-cli x.y.z 且結束碼 0；
# 輔助程式回 pipe-in 錯誤且結束碼非 0。（不能用檔案大小：winget 裝的 codex
# 在 PATH 上是個小小的連結檔。）
function Test-RealCodex($path) {
  try {
    $out = & $path --version 2>&1
    return (($LASTEXITCODE -eq 0) -and ("$out" -match "codex"))
  } catch { return $false }
}

# 到 winget 的套件目錄找 codex 主程式（長檔名）。
# winget 在「沒開發者模式、又非系統管理員」的電腦上建不出 Links 目錄的
# codex.exe 捷徑（symlink 權限不足，Links 目錄是空的），退而求其次只把
# 套件目錄塞進 PATH——但執行檔仍叫 codex-x86_64-pc-windows-msvc.exe，
# 打「codex」永遠找不到。一般使用者的電腦大多是這個狀態。
function Find-CodexPackageExe {
  foreach ($r in @("$env:LOCALAPPDATA\Microsoft\WinGet\Packages",
                   "$env:ProgramFiles\WinGet\Packages")) {
    if (-not (Test-Path $r)) { continue }
    $hit = Get-ChildItem $r -Directory -Filter "OpenAI.Codex*" -ErrorAction SilentlyContinue |
      ForEach-Object { Get-ChildItem $_.FullName -Filter "codex-*-pc-windows-msvc.exe" -ErrorAction SilentlyContinue } |
      Select-Object -First 1
    if ($hit) { return $hit.FullName }
  }
  return $null
}

function Install-Codex {
  $exe = Join-Path $bin "codex.exe"

  # 自我修復：先前版本誤裝的假 codex（其實是 command-runner）要主動換掉，
  # 不能因為「檔案存在」就跳過安裝——否則使用者永遠卡在 pipe-in 錯誤。
  if ((Test-Path $exe) -and -not (Test-RealCodex $exe)) {
    Write-Host ">> 偵測到先前誤裝的 codex（其實是沙箱輔助程式），移除後重新安裝..."
    Remove-Item $exe -Force
  }

  $existing = Get-Command codex -ErrorAction SilentlyContinue
  if ($existing -and (Test-RealCodex $existing.Source)) {
    Write-Host "OK Codex CLI 已經裝過了，跳過安裝。"
    $exe = $existing.Source
  } elseif (Test-Path $exe) {
    Write-Host "OK Codex CLI 已經裝過了，跳過安裝。"
  } else {
    # 優先用 winget 裝官方套件（OpenAI.Codex，發行者 OpenAI, Inc.）：
    # 由 winget 驗證雜湊、自動處理相依與 PATH，也不會碰到上面那個三檔陷阱。
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
      Write-Host ">> 正在用 winget 安裝官方 Codex CLI（下載約 114 MB，請稍候）..."
      & winget install -e --id OpenAI.Codex --accept-package-agreements --accept-source-agreements
      # winget 把指令加進「新視窗」的 PATH；本視窗要自己補 WinGet Links 目錄。
      $links = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links"
      if (Test-Path $links) { $env:Path = "$env:Path;$links" }
      $found = Get-Command codex -ErrorAction SilentlyContinue
      if ($found -and (Test-RealCodex $found.Source)) {
        $exe = $found.Source
        Write-Host "OK Codex CLI 已裝好（winget 官方套件）"
      } else {
        # winget 的捷徑沒建起來（見 Find-CodexPackageExe 說明）——自己修：
        # 在套件目錄就地建一個 codex.exe 硬連結（不佔額外空間；建不了就複製）。
        # 註：winget upgrade 會清掉套件目錄重建、捷徑會消失——所以伺服器端的
        # find_cli 也會直接找長檔名，且重跑本安裝器就會再修一次。
        $pkg = Find-CodexPackageExe
        if ($pkg) {
          $link = Join-Path (Split-Path $pkg) "codex.exe"
          if (-not (Test-Path $link)) {
            try { New-Item -ItemType HardLink -Path $link -Value $pkg -ErrorAction Stop | Out-Null }
            catch { Copy-Item $pkg $link -ErrorAction SilentlyContinue }
          }
          if (Test-Path $link) {
            $exe = $link
            Write-Host "OK Codex CLI 已裝好（winget 套件＋自動修補捷徑）"
          }
        }
      }
    }
    if (-not (Test-Path $exe) -and -not (Get-Command codex -ErrorAction SilentlyContinue)) {
      $arch = if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { "aarch64" } else { "x86_64" }
      Write-Host ">> winget 不可用，改為下載官方執行檔（$arch 版）..."
      $tmp = Join-Path $env:TEMP "codex-dl.zip"
      Invoke-WebRequest -Uri "https://github.com/openai/codex/releases/latest/download/codex-$arch-pc-windows-msvc.exe.zip" -OutFile $tmp
      # 解除封鎖：下載來的檔案帶 Mark-of-the-Web，解壓後每個檔案都繼承，會被擋。
      Unblock-File -Path $tmp -ErrorAction SilentlyContinue
      Expand-Archive -Path $tmp -DestinationPath $bin -Force
      Remove-Item $tmp -Force
      Get-ChildItem $bin -Filter "*.exe" | ForEach-Object { Unblock-File $_.FullName -ErrorAction SilentlyContinue }
      # 只改名主程式（見 Test-RealCodex 上方說明）；command-runner 與
      # sandbox-setup 必須以原名留在同一個資料夾，codex 會照名字找它們。
      $f = Get-ChildItem $bin -Filter "codex-*-pc-windows-msvc.exe" | Select-Object -First 1
      if ($f) {
        Move-Item $f.FullName $exe -Force
        Write-Host "OK Codex CLI 已裝到 $exe"
      } else {
        Write-Host "!! 解壓後找不到 codex 主程式。請先安裝 winget（Microsoft Store 搜「應用程式安裝程式」）再重跑本安裝器。"
        $script:LoginFailed += "GPT"
        return
      }
    }
  }
  $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
  if ($userPath -notlike "*$bin*") {
    [Environment]::SetEnvironmentVariable("Path", "$userPath;$bin", "User")
  }
  $env:Path = "$env:Path;$bin"

  # 最後防線：登入前確認手上這份是真品，不是就別浪費使用者時間走登入流程。
  if (-not (Test-RealCodex $exe)) {
    $script:LoginFailed += "GPT"
    Write-Host ""
    Write-Host "!! 這份 codex 執行檔不正常（回應不是版本號）。"
    Write-Host "   請改用 winget 安裝後再重跑本安裝器："
    Write-Host "     winget install -e --id OpenAI.Codex"
    return
  }

  # codex 會輸出 ANSI 色彩控制碼；本視窗（傳統主控台）不解析，會顯示成
  # 「[90m」之類的亂碼，蓋住使用者要抄的代碼與網址。NO_COLOR 是通用約定
  # （no-color.org），讓它改輸出乾淨的純文字。
  $env:NO_COLOR = "1"

  Write-Host ""
  Write-Host ">> 接著登入 GPT。"
  Write-Host "   畫面會給你一組代碼和一個網址：用瀏覽器打開網址、貼上代碼、"
  Write-Host "   登入你的 ChatGPT 帳號，這個視窗就會自己完成。"
  Read-Host "  準備好就按 Enter 開始登入" | Out-Null

  # 裝置碼登入（--device-auth）：給一組代碼與網址，不需要瀏覽器回呼本機連接埠，
  # 在防火牆受限的環境最穩。萬一這版 codex 不支援，退回一般瀏覽器登入。
  $ok = $false
  try {
    & $exe login --device-auth
    $ok = ($LASTEXITCODE -eq 0)
  } catch { $ok = $false }

  if (-not $ok) {
    Write-Host ""
    Write-Host ">> 裝置碼登入沒成功，改用瀏覽器登入再試一次..."
    try {
      & $exe login
      $ok = ($LASTEXITCODE -eq 0)
    } catch { $ok = $false }
  }

  if (-not $ok) {
    $script:LoginFailed += "GPT"
    Write-Host ""
    Write-Host "!! GPT 登入沒有完成。"
    Write-Host "   請自己開一個「終端機」視窗（不用系統管理員），貼上下面這行按 Enter："
    Write-Host "     codex login --device-auth"
    Write-Host "   Claude 不受影響，可以先只用 Claude 開會。"
  } else {
    Write-Host ""
    Write-Host "OK GPT 已登入。"
  }
}

function Install-Gemini {
  Write-Host ""
  # ⚠️ 本視窗的 PATH 繼承自 App 啟動當下——使用者「剛剛才裝好 Node.js」的話，
  # 這裡還看不到 npm（Windows 只把新 PATH 給之後新開的程式）。先把 Node 與
  # npm 全域目錄的標準位置補進來，使用者才不用整個 App 重開再走一次流程。
  foreach ($d in @("$env:ProgramFiles\nodejs",
                   "${env:ProgramFiles(x86)}\nodejs",
                   "$env:APPDATA\npm")) {
    if ($d -and (Test-Path $d) -and ($env:Path -notlike "*$d*")) { $env:Path = "$env:Path;$d" }
  }
  if (Get-Command gemini -ErrorAction SilentlyContinue) {
    Write-Host "OK Gemini CLI 已經裝過了，跳過安裝。"
  } else {
    if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
      # 一鍵原則：Node.js 由安裝器自動裝，不叫使用者自己去 nodejs.org。
      $winget = Get-Command winget -ErrorAction SilentlyContinue
      if ($winget) {
        Write-Host ">> Gemini 需要 Node.js，正在自動安裝（一次性，約 2 分鐘）..."
        & winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
        foreach ($d in @("$env:ProgramFiles\nodejs", "${env:ProgramFiles(x86)}\nodejs")) {
          if ($d -and (Test-Path $d) -and ($env:Path -notlike "*$d*")) { $env:Path = "$env:Path;$d" }
        }
      }
    }
    if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
      Write-Host "X Node.js 自動安裝沒有成功。"
      Write-Host "  請到 https://nodejs.org 下載 LTS 版安裝，裝完後重新執行本安裝器選 4。"
      $script:LoginFailed += "Gemini"
      Read-Host "按 Enter 返回" | Out-Null
      return
    }
    Write-Host ">> 正在安裝 Gemini CLI（約一分鐘）..."
    npm install -g @google/gemini-cli
    if ($LASTEXITCODE -ne 0) {
      Write-Host "!! Gemini CLI 安裝失敗，請截圖上面的錯誤訊息回報。"
      $script:LoginFailed += "Gemini"
      Read-Host "按 Enter 返回" | Out-Null
      return
    }
    # npm 第一次全域安裝後才會出現的指令目錄，本視窗要自己補進 PATH
    if ((Test-Path "$env:APPDATA\npm") -and ($env:Path -notlike "*$env:APPDATA\npm*")) {
      $env:Path = "$env:Path;$env:APPDATA\npm"
    }
  }
  Write-Host ""
  Write-Host ">> 接著登入 Gemini，三個重點："
  Write-Host "   1. 等一下的畫面裡，選第一項「Login with Google」按 Enter"
  Write-Host "   2. 瀏覽器跳出登入頁：用「個人」Google 帳號登入（避開公司/學校帳號）"
  Write-Host "   3. 瀏覽器說成功後，回到這個視窗「等它顯示完成」再離開（太早關＝白登）"
  Read-Host "  準備好就按 Enter 開始登入" | Out-Null
  gemini

  # ⚠️ 不能只看流程有沒有跑完——使用者在瀏覽器看到 Google 說成功就把視窗關掉的話，
  # 憑證根本沒存進電腦（實測踩過：「以為成功了，結果是假的」）。驗證憑證檔才算數。
  if (Test-Path (Join-Path $env:USERPROFILE ".gemini\oauth_creds.json")) {
    Write-Host ""
    Write-Host "OK Gemini 已登入（憑證已確認存在）。"
  } else {
    $script:LoginFailed += "Gemini"
    Write-Host ""
    Write-Host "!! Gemini 看起來還沒真正登入成功（找不到登入憑證）。"
    Write-Host "   請重跑本安裝器選 4，這次照上面三個重點做，"
    Write-Host "   特別是最後一步：瀏覽器完成後要回來等這個視窗顯示完成。"
  }
}

switch ($ch) {
  "1" { Install-Claude }
  "2" { Install-Codex }
  "3" { Install-Claude; Install-Codex }
  default { Write-Host "沒有選擇，結束。" }
}

Write-Host ""
Write-Host "=========================================="
if ($script:LoginFailed.Count -gt 0) {
  Write-Host "  尚未完成：$($script:LoginFailed -join '、') 的安裝或登入還沒完成。"
  Write-Host "  請照上面的提示補完，或改裝另一家。"
  Write-Host "  （只要有任何一家登入成功，就能開會。）"
} else {
  Write-Host "  完成！回到「AI 董事會」視窗按「重新檢查」。"
  Write-Host "  這個視窗可以關掉。"
}
Write-Host "=========================================="
Read-Host "按 Enter 結束" | Out-Null
